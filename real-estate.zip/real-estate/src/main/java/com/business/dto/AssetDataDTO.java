package com.business.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AssetDataDTO {

	@JsonProperty("address")
	private String assetAddress;

	@JsonProperty("zipcode")
	private String assetZipcode;

	@JsonProperty("city")
	private String assetCity;
	
	@JsonProperty("year_of_construction")
	private String assetYoc;
	
	@JsonProperty("restricted_area")
	private boolean assetIsRestricted;

	@JsonProperty("number_of_units")
	private Long unitSize;
	
	@JsonProperty("total_rent")
	private Long totalRent;
	
	@JsonProperty("total_area")
	private Long totalArea;

	@JsonProperty("area_rented")
	private Long areaRented;
	
	@JsonProperty("vacancy")
	private String vacancy;

	@JsonProperty("walt")
	private Double walt;

	@JsonProperty("latest_update")
	private LocalDate lastUpdate;

	public String getAssetAddress() {
		return assetAddress;
	}

	public void setAssetAddress(String assetAddress) {
		this.assetAddress = assetAddress;
	}

	public String getAssetZipcode() {
		return assetZipcode;
	}

	public void setAssetZipcode(String assetZipcode) {
		this.assetZipcode = assetZipcode;
	}

	public String getAssetCity() {
		return assetCity;
	}

	public void setAssetCity(String assetCity) {
		this.assetCity = assetCity;
	}

	public String getAssetYoc() {
		return assetYoc;
	}

	public void setAssetYoc(String assetYoc) {
		this.assetYoc = assetYoc;
	}

	public boolean isAssetIsRestricted() {
		return assetIsRestricted;
	}

	public void setAssetIsRestricted(boolean assetIsRestricted) {
		this.assetIsRestricted = assetIsRestricted;
	}

	public Long getUnitSize() {
		return unitSize;
	}

	public void setUnitSize(Long unitSize) {
		this.unitSize = unitSize;
	}

	public Long getTotalRent() {
		return totalRent;
	}

	public void setTotalRent(Long totalRent) {
		this.totalRent = totalRent;
	}

	public Long getTotalArea() {
		return totalArea;
	}

	public void setTotalArea(Long totalArea) {
		this.totalArea = totalArea;
	}

	public Long getAreaRented() {
		return areaRented;
	}

	public void setAreaRented(Long areaRented) {
		this.areaRented = areaRented;
	}

	public String getVacancy() {
		return vacancy;
	}

	public void setVacancy(String vacancy) {
		this.vacancy = vacancy;
	}

	public Double getWalt() {
		return walt;
	}

	public void setWalt(Double walt) {
		this.walt = walt;
	}

	public LocalDate getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(LocalDate lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
}
