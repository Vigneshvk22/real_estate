package com.business.dto;

import org.springframework.http.HttpStatus;

import lombok.Getter;

@Getter
public class ResponseDTO {

	private boolean status;

	private String message;

	private HttpStatus httpstatus;

	private Object payload;

	public ResponseDTO(boolean status, String message, HttpStatus httpstatus, Object payload) {
		super();
		this.status = status;
		this.message = message;
		this.httpstatus = httpstatus;
		this.payload = payload;
	}

	public boolean isStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	public HttpStatus getHttpstatus() {
		return httpstatus;
	}

	public Object getPayload() {
		return payload;
	}

}
