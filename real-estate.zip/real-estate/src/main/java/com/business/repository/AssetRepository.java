package com.business.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.business.entity.AssetData;

@Repository
public interface AssetRepository extends JpaRepository<AssetData, Long> {

	public Optional<AssetData> findByUnitRefAndUnitType(String unitRef, String unitType);

	public List<AssetData> findByAssetRef(String assetRef);

}
