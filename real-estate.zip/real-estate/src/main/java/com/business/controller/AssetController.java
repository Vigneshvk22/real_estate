package com.business.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.business.service.AssetService;

@RestController
public class AssetController {

	@Autowired
	private AssetService assetService;

	@GetMapping("/assets")
	public ResponseEntity<?> getAssets(@RequestParam(required= false) String assetRef) {
		return assetService.getAssets(assetRef);
	}
}
