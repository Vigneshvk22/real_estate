package com.business.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="asset_data")
@Getter
@Setter
public class AssetData {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@Column(name="portfolio")
	private String portfolio;

	@Column(name="asset_ref")
	private String assetRef;

	@Column(name="asset_address")
	private String assetAddress;

	@Column(name="asset_zipcode")
	private String assetZipcode;

	@Column(name="asset_city")
	private String assetCity;

	@Column(name="asset_is_restricted")
	private boolean assetIsRestricted;

	@Column(name="asset_yoc")
	private String assetYoc;

	@Column(name="unit_ref")
	private String unitRef;

	@Column(name="unit_size")
	private String unitSize;

	@Column(name="unit_is_rented")
	private boolean unitIsRented;

	@Column(name="unit_rent")
	private String unitRent;

	@Column(name="unit_type")
	private String unitType;

	@Column(name="unit_tenant")
	private String unitTenant;

	@Column(name="unit_lease_start")
	private String unitLeaseStart;

	@Column(name="unit_lease_end")
	private String unitLeaseEnd;

	@Column(name="data_timestamp")
	private String dataTimestamp;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}

	public String getAssetRef() {
		return assetRef;
	}

	public void setAssetRef(String assetRef) {
		this.assetRef = assetRef;
	}

	public String getAssetAddress() {
		return assetAddress;
	}

	public void setAssetAddress(String assetAddress) {
		this.assetAddress = assetAddress;
	}

	public String getAssetZipcode() {
		return assetZipcode;
	}

	public void setAssetZipcode(String assetZipcode) {
		this.assetZipcode = assetZipcode;
	}

	public String getAssetCity() {
		return assetCity;
	}

	public void setAssetCity(String assetCity) {
		this.assetCity = assetCity;
	}

	public boolean isAssetIsRestricted() {
		return assetIsRestricted;
	}

	public void setAssetIsRestricted(boolean assetIsRestricted) {
		this.assetIsRestricted = assetIsRestricted;
	}

	public String getAssetYoc() {
		return assetYoc;
	}

	public void setAssetYoc(String assetYoc) {
		this.assetYoc = assetYoc;
	}

	public String getUnitRef() {
		return unitRef;
	}

	public void setUnitRef(String unitRef) {
		this.unitRef = unitRef;
	}

	public String getUnitSize() {
		return unitSize;
	}

	public void setUnitSize(String unitSize) {
		this.unitSize = unitSize;
	}

	public boolean isUnitIsRented() {
		return unitIsRented;
	}

	public void setUnitIsRented(boolean unitIsRented) {
		this.unitIsRented = unitIsRented;
	}

	public String getUnitRent() {
		return unitRent;
	}

	public void setUnitRent(String unitRent) {
		this.unitRent = unitRent;
	}

	public String getUnitType() {
		return unitType;
	}

	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}

	public String getUnitTenant() {
		return unitTenant;
	}

	public void setUnitTenant(String unitTenant) {
		this.unitTenant = unitTenant;
	}

	public String getUnitLeaseStart() {
		return unitLeaseStart;
	}

	public void setUnitLeaseStart(String unitLeaseStart) {
		this.unitLeaseStart = unitLeaseStart;
	}

	public String getUnitLeaseEnd() {
		return unitLeaseEnd;
	}

	public void setUnitLeaseEnd(String unitLeaseEnd) {
		this.unitLeaseEnd = unitLeaseEnd;
	}

	public String getDataTimestamp() {
		return dataTimestamp;
	}

	public void setDataTimestamp(String dataTimestamp) {
		this.dataTimestamp = dataTimestamp;
	}

}
