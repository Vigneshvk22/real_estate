package com.business.service.impl;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.business.dto.AssetDataDTO;
import com.business.dto.ResponseDTO;
import com.business.entity.AssetData;
import com.business.repository.AssetRepository;
import com.business.service.AssetService;

@Service
public class AssetServiceImpl implements AssetService {

	public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yy");

	@Autowired
	AssetRepository assetRepository;

	@Override
	public ResponseEntity<?> getAssets(String assetRef) {
		if(assetRef != null) {
			List<AssetData> assetData = assetRepository.findByAssetRef(assetRef);
			if(assetData != null) {
				return new ResponseEntity<>(new ResponseDTO(true, "Sucess", HttpStatus.OK,groupassetByassetRef(assetData)), HttpStatus.OK);
			}
			else
				return new ResponseEntity<>(new ResponseDTO(false, "Not found", HttpStatus.BAD_REQUEST,null), HttpStatus.BAD_REQUEST);
		}
		else {
			List<AssetData> assetDataList = assetRepository.findAll(Sort.by("id").ascending());
			return new ResponseEntity<>(new ResponseDTO(true, "Sucess", HttpStatus.OK,groupassetByassetRef(assetDataList)), HttpStatus.OK);
		}
	}

	private List<AssetDataDTO> groupassetByassetRef(List<AssetData> assetDataList) {
		List<AssetDataDTO> assetDataDTOList = new ArrayList<>();
		Map<String, List<AssetData>> assetDataMap = new HashMap<>();
		DecimalFormat df = new DecimalFormat("#.##");  
		assetDataList.forEach(assetData ->{
			List<AssetData> assets = assetDataMap.get(assetData.getAssetRef());
			if(assets == null) {
				assets = new ArrayList<>();
				assets.add(assetData);
				assetDataMap.put(assetData.getAssetRef(), assets);
			}
			else {
				assets.add(assetData);
				assetDataMap.put(assetData.getAssetRef(), assets);
			}
		});
		assetDataMap.entrySet().forEach(assets ->{
			AssetDataDTO assetDataDTO = new AssetDataDTO();
			AssetData assetEntity = assets.getValue().get(0);
			assetDataDTO.setAssetAddress(assetEntity.getAssetAddress());
			assetDataDTO.setAssetZipcode(assetEntity.getAssetZipcode());
			assetDataDTO.setAssetCity(assetEntity.getAssetCity());
			assetDataDTO.setAssetYoc(assetEntity.getAssetYoc());
			assetDataDTO.setAssetIsRestricted(assetEntity.isAssetIsRestricted());
			Long unitSize = 0L;
			Long totalRent = 0L;
			Long totalArea = Long.valueOf(assets.getValue().size());
			Long availableTenants = 0L;
			for (AssetData assetData : assets.getValue()) {
				unitSize += Long.valueOf(assetData.getUnitSize());
				totalRent += Long.valueOf(assetData.getUnitRent().equals("")?"0":assetData.getUnitRent());
				if(assetData.getUnitTenant() != null && !assetData.getUnitTenant().isEmpty())
					availableTenants +=1; 
			}
			
			
			Double totalWalt = 0.00;
			for (AssetData assetData : assets.getValue()) {
				if(assetData.getUnitLeaseEnd() != null && !assetData.getUnitLeaseEnd().isEmpty() && assetData.isUnitIsRented() == true) {
				 LocalDate c_end = LocalDate.parse(assetData.getUnitLeaseEnd(), FORMATTER);
				 LocalDate ct_date= LocalDate.parse(assetData.getDataTimestamp(),FORMATTER);
				 Double monthsDiff= (double) ChronoUnit.MONTHS.between(ct_date, c_end);
				 Double diff = (monthsDiff/12);
				 
				 Float currentUnit = Float.valueOf(assetData.getUnitSize());
				 Float unitPercentage = (currentUnit/unitSize);
				 Double waltValue = unitPercentage * diff;
				 totalWalt =  (totalWalt + waltValue);
				}
				else {
					totalWalt += totalWalt;
				}
				
			}
			    
			totalWalt = Double.valueOf(df.format(totalWalt));
			assetDataDTO.setUnitSize(unitSize);
			assetDataDTO.setTotalRent(totalRent);
			assetDataDTO.setTotalArea(totalArea);
			assetDataDTO.setAreaRented(availableTenants);
			Long freeassets = totalArea - availableTenants;
			if(freeassets > 0) {
				Float value =Float.valueOf(freeassets)/Float.valueOf(totalArea);
				Long vacancy = (long) (value * 100);
				assetDataDTO.setVacancy(vacancy+"%");
			}
			else
				assetDataDTO.setVacancy(freeassets+"%");
			assetDataDTO.setWalt(totalWalt);
			assetDataDTO.setLastUpdate(LocalDate.parse(assetEntity.getDataTimestamp(),FORMATTER));
			assetDataDTOList.add(assetDataDTO);
		});
		return assetDataDTOList;
	}

}
