package com.business.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.business.dto.ResponseDTO;
import com.business.entity.AssetData;
import com.business.repository.AssetRepository;
import com.business.service.ImportService;

@Service
public class ImportServiceImpl implements ImportService {

	public final static String USER_HOME = System.getProperty("user.home");

	@Value("${file.store.path}")
	private String path;

	@Autowired
	AssetRepository assetRepository;

	@Override
	public ResponseEntity<?> importFile(MultipartFile file) {
		String fileName = System.currentTimeMillis()+"_"+file.getOriginalFilename().replaceAll("\\s+", "");
		String filePath = USER_HOME+path+fileName;
		List<AssetData> importDataDTOList = new ArrayList<>();
		try {
			if (Files.notExists(Paths.get(USER_HOME+path)))
				new File(USER_HOME+path).mkdir();
			Files.write(Paths.get(filePath), file.getBytes());
			InputStream csvInputs = new FileInputStream(filePath);
			BufferedReader reader = new BufferedReader(new InputStreamReader(csvInputs));
			List<String> inputDataList = reader.lines().skip(1).filter(data-> !data.isEmpty()).collect(Collectors.toList());
			inputDataList.forEach( input ->{
				List<String> currentRecord = new ArrayList<>(Arrays.asList(input.split(";")));
				importDataDTOList.add(dataToObject(currentRecord));
			});
			CompletableFuture.runAsync(() -> updateAssets(importDataDTOList));
			reader.close();
			return new ResponseEntity<>(new ResponseDTO(true, "Sucess", HttpStatus.OK, null),HttpStatus.OK);
		}
		catch (Exception e) {
			return new ResponseEntity<>(new ResponseDTO(true, "File conversion error", HttpStatus.BAD_REQUEST, null),HttpStatus.BAD_REQUEST);
		}
	}

	public void updateAssets(List<AssetData> importDataDTOList) {
		importDataDTOList.forEach(importData ->{
			synchronized (this) {
				Optional<AssetData> assetData = assetRepository.findByUnitRefAndUnitType(importData.getUnitRef(),importData.getUnitType());
				if(assetData.isPresent()) {
					importData.setId(assetData.get().getId());
					assetRepository.save(importData);
				}
				else
					assetRepository.save(importData);
			}
		});
	}

	public AssetData dataToObject(List<String> currentRecord) {
		AssetData importDataDTO = new AssetData();
		importDataDTO.setPortfolio(currentRecord.get(0));
		importDataDTO.setAssetRef(currentRecord.get(1));
		importDataDTO.setAssetAddress(currentRecord.get(2));
		importDataDTO.setAssetZipcode(currentRecord.get(3));
		importDataDTO.setAssetCity(currentRecord.get(4));
		if(currentRecord.get(5) != null && currentRecord.get(5).equals("TRUE"))
			importDataDTO.setAssetIsRestricted(true);
		importDataDTO.setAssetYoc(currentRecord.get(6));
		importDataDTO.setUnitRef(currentRecord.get(7));
		importDataDTO.setUnitSize(currentRecord.get(8));
		if(currentRecord.get(9) != null && currentRecord.get(9).equals("TRUE"))
			importDataDTO.setUnitIsRented(true);
		importDataDTO.setUnitRent(currentRecord.get(10));
		importDataDTO.setUnitType(currentRecord.get(11));
		importDataDTO.setUnitTenant(currentRecord.get(12));
		importDataDTO.setUnitLeaseStart(currentRecord.get(13));
		importDataDTO.setUnitLeaseEnd(currentRecord.get(14));
		importDataDTO.setDataTimestamp(currentRecord.get(15));
		return importDataDTO;
	}

}
