package com.business.service;

import org.springframework.http.ResponseEntity;

public interface AssetService {

	public ResponseEntity<?> getAssets(String assetRef);

}
